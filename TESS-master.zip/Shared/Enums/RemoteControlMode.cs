﻿namespace Remotely.Shared.Enums
{
    public enum RemoteControlMode
    {
        None,
        Unattended,
        Normal
    }
}
