﻿namespace Remotely.Shared.Models
{
    public class DeviceSetupOptions
    {
        public string DeviceAlias { get; set; }
        public string DeviceGroup { get; set; }
    }
}
