﻿namespace Remotely.Shared.Models
{
    public class ScreenCastRequest
    {
        public string ViewerID { get; set; }
        public string RequesterName { get; set; }
    }
}
