﻿using ReactiveUI;

namespace Remotely.Desktop.Linux.ViewModels
{
    public class ViewModelBase : ReactiveObject
    {
    }
}
