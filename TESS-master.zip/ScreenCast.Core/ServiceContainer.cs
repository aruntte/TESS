﻿using System;

namespace Remotely.ScreenCast.Core
{
    public class ServiceContainer
    {
        public static IServiceProvider Instance { get; set; }
    }
}
