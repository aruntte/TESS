﻿namespace Remotely.ScreenCast.Core.Enums
{
    public enum AppMode
    {
        Unattended,
        Normal,
        Chat
    }
}
