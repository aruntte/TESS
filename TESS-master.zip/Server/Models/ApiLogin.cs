﻿namespace Remotely.Server.Models
{
    public class ApiLogin
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
