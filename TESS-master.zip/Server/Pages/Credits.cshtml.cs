using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Remotely.Server.Pages
{
    public class CreditsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}