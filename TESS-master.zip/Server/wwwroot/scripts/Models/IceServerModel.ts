﻿export class IceServerModel {
    Url: string;
    TurnPassword: string;
    TurnUsername: string;
}