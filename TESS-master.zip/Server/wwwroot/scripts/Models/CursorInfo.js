export {};
//# sourceMappingURL=CursorInfo.js.map