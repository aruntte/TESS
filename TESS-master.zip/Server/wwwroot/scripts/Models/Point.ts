﻿export interface Point {
    X: number;
    Y: number;
    IsEmpty: boolean;
}