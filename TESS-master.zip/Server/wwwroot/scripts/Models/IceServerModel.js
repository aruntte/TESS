export class IceServerModel {
}
//# sourceMappingURL=IceServerModel.js.map