export {};
//# sourceMappingURL=GenericCommandResult.js.map