export {};
//# sourceMappingURL=CommandResult.js.map