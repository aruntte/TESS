export {};
//# sourceMappingURL=PSCoreCommandResult.js.map