export class CommandLineParameter {
    constructor(name, value) {
        this.Name = name;
        this.Value = value;
    }
}
//# sourceMappingURL=CommandLineParameter.js.map