export var RemoteControlMode;
(function (RemoteControlMode) {
    RemoteControlMode[RemoteControlMode["None"] = 0] = "None";
    RemoteControlMode[RemoteControlMode["Unattended"] = 1] = "Unattended";
    RemoteControlMode[RemoteControlMode["Normal"] = 2] = "Normal";
})(RemoteControlMode || (RemoteControlMode = {}));
//# sourceMappingURL=RemoteControlMode.js.map