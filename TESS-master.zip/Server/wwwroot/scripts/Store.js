export const Store = new class {
    constructor() {
        this.CommandCompletionPosition = -1;
        this.InputHistoryPosition = -1;
        this.InputHistoryItems = [];
    }
};
//# sourceMappingURL=Store.js.map