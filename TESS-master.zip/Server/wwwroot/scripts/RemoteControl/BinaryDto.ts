﻿import { BinaryDtoType } from "../Enums/BinaryDtoType.js";

export interface BinaryDto {
    DtoType: BinaryDtoType
}