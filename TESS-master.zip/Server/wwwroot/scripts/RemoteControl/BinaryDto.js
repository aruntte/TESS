export {};
//# sourceMappingURL=BinaryDto.js.map