# Installation
> `npm install --save @types/bootstrap`

# Summary
This package contains type definitions for Bootstrap (https://github.com/twbs/bootstrap/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/bootstrap

Additional Details
 * Last updated: Mon, 08 Jul 2019 21:09:27 GMT
 * Dependencies: @types/popper.js, @types/jquery
 * Global values: Bootstrap

# Credits
These definitions were written by denisname <https://github.com/denisname>.
